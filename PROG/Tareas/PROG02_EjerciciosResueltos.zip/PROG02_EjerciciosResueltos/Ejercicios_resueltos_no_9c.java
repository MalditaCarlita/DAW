/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicios_resueltos_no_9c;

/**
 *
 * @author yo
 */
public class Ejercicios_resueltos_no_9c {

    public static void main(String[] args) {
        int min = 0; 
        int H = 5;
        min = H * 60;
        System.out.println("En " +H +" horas hay " +min +" minutos");
    }
}
