/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funciones;

/**
 *
 * @author yo
 */
public class DataBase {
    public static ArtigoStock stocks;
    public static ClientesStorage totalClientes;
    public static ArtigosStorage totalArtigos;
    public static VentasStorage totalVentas;
    public static FacturasStorage totalFacturas; 
}
