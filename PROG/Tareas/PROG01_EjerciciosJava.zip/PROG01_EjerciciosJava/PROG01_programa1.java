public class PROG01_programa1 {

    public static void main(String[] args) {
    System.out.println("Módulo Profesional - PROGRAMACIÓN. UNIDAD DE TRABAJO 01");

    System.out.println("Introducción a la programación");

    System.out.println("Carla Portela Ubeira");

    System.out.println("Moaña, Pontevdra");

    System.out.println("20 de septiembre de 2022");

    System.out.println("Programa1");
    }

}