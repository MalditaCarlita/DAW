package funcións;

public class Database {
    public static ClientesStorage tclientes=new ClientesStorage();
    public static ArtigoStock stock=new ArtigoStock();
    public static ArtigosStorage tartigos=new ArtigosStorage();
    public static VentasStorage tventas=new VentasStorage();
    public static FacturasStorage tfacturas=new FacturasStorage();
}
