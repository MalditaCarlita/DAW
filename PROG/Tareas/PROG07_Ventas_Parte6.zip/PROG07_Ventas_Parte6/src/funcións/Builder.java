package funcións;

public interface Builder<K> {
    public K build() throws Exception; 
}
