package principal;

class CancelException extends Exception {}
