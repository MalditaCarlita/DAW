package game;

public class GameException extends Exception {
    public GameException(String error) {
        super(error);
    }
}
