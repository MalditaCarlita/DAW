
package game;

/**
 *
 * @author xavi
 */
public class EndAction extends GameAction {
    
    public EndAction(Player player) {
        super(player, Action.END);
    }
    
}
