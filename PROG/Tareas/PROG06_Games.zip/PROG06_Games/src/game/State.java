package game;

public enum State {
    STOPPED,RUNNING,ENDED,WIN,LOSE,TIE;
}
