package game;

public enum Action {
    CLICK,END;
}
